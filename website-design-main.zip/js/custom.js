$(function(){
	/*=== Navbar ===*/ 
	$(".navbar-toggler").on('click', function() {
        $(this).toggleClass("active");
    });
	var subMenu = $('.navigation .navbar-nav .sub-menu');
});